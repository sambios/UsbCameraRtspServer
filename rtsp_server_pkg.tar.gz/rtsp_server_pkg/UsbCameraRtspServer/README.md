# UsbCameraRtspServer
USBCamera RTSP server and file server.
Tested on Windows 10 and ubuntu 16.04.
